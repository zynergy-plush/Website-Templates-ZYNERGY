To start off,

Make an account at https://unsplash.com/login.

Then go to https://unsplash.com/oauth/applications and make a new application, you can give any description and title.

When you edit the application, scroll down and find your access key.

Find the "script.js" file in this template package.
Paste your access key in the "const accessKey = "[your access key]" (in the first line)

And always make sure to extract the files.