Thank You for downloading this template! To get started, follow the steps below:

1. There are some changeable lines of code. Those are: 17, 18 | 37 | 41, 42 | 48 | 77
   You can Change them to make the Portfolio to be more personal.
2. To make a download, put your file in the "downloads", and in line 48, type "downloads/[whatever is your file name]" in the href
   attribute.

And your portfolio template is ready to go!